//
//  ViewController.m
//  music
//
//  Created by Dragon_Zheng on 2/5/25.
//

#import "EGFanDetailViewController.h"
@interface EGFanDetailViewController ()
@property (nonatomic,strong)UIImageView *girlView;
@property (nonatomic,strong)UIImageView *showgirlView;
@property (nonatomic,strong)UILabel *girlNameTitle;
@property (nonatomic,strong)UILabel *girlNameContent;
@property (nonatomic,strong)UILabel *girlSecondNameTitle;
//@property (nonatomic,strong)UILabel *girlSecondNameContent;
@property (nonatomic,strong)UILabel *girlBirthdayTitle;
@property (nonatomic,strong)UILabel *girlBirthdayContent;
@property (nonatomic,strong)UILabel *girlStarTitle;
@property (nonatomic,strong)UILabel *girlStarContent;

@property (nonatomic,strong)UIImageView *line1View;
@property (nonatomic,strong)UIImageView *line2View;
@property (nonatomic,strong)UIImageView *line3View;
@property (nonatomic,strong)UIImageView *line4View;

@property (nonatomic,strong)UIButton *facebookbt;
@property (nonatomic,strong)UIButton *twtiterbt;

@property (nonatomic,strong)UILabel *Nolable_inImage;
@property (nonatomic,strong)UILabel *Namelable_inImage;
@property (nonatomic,strong)UILabel *SecondNamelable_inImage;
@end

@implementation EGFanDetailViewController
- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.navigationItem.title = @"鷹援資訊";
    [self setupUI];
    [self setInfo:self.girlDetailinfo];
    
}

-(void)setupUI
{
    UIView *bView = [[UIView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, Device_Height)];
    bView.backgroundColor = UIColor.whiteColor;
    [self.view addSubview:bView];
    
    
    UIImageView *gView = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 20)];
    
    gView.image = [UIImage imageNamed:@"Imageback"];
    [self.view addSubview:gView];
    [gView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo([UIDevice de_navigationFullHeight]);
        make.left.mas_equalTo(0);
        make.height.mas_equalTo(ScaleW(242));
        make.width.mas_equalTo(Device_Width);
    }];
    self.girlView = gView;
    
    //个人图片上面显示4个信息
    gView = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 20)];
    gView.contentMode = UIViewContentModeScaleAspectFill;
    [ self.girlView addSubview:gView];
    [gView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(0);
        make.right.mas_equalTo(ScaleW(-20));
        make.height.mas_equalTo(ScaleW(242));
        make.width.mas_equalTo(ScaleW(200));
    }];
    self.showgirlView = gView;
    
    
    UILabel *labelinimage = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], 40, 67)];
    labelinimage.textColor = UIColor.whiteColor;
    labelinimage.font = [UIFont boldSystemFontOfSize:FontSize(40)];
    [self.girlView addSubview:labelinimage];
    [labelinimage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(ScaleW(91));
        make.left.mas_equalTo(ScaleW(28));
        make.height.mas_equalTo(ScaleW(67));
        make.width.mas_equalTo(ScaleW(60));
    }];
    self.Nolable_inImage = labelinimage;
    
    
    labelinimage = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], 72, 34)];
    labelinimage.textColor = UIColor.whiteColor;
    labelinimage.font = [UIFont systemFontOfSize:FontSize(20)];
    [self.girlView addSubview:labelinimage];
    [labelinimage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(ScaleW(158));
        make.left.mas_equalTo(ScaleW(28));
        make.height.mas_equalTo(ScaleW(34));
        make.width.mas_equalTo(ScaleW(72));
    }];
    self.Namelable_inImage = labelinimage;
    
    
    labelinimage = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], 63, 22)];
    labelinimage.textColor = UIColor.whiteColor;
    labelinimage.font = [UIFont systemFontOfSize:FontSize(16)];
    [self.girlView addSubview:labelinimage];
    [labelinimage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.Namelable_inImage.mas_bottom);
        make.left.mas_equalTo(ScaleW(28));
        make.height.mas_equalTo(ScaleW(22));
//        make.width.mas_equalTo(ScaleW(63));
    }];
    self.SecondNamelable_inImage = labelinimage;
    
    
    //Name
    UILabel *name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
    name.text = @"姓名";
    name.font = [UIFont systemFontOfSize:FontSize(16)];
    name.textColor = rgba(113,113,122,1);
    [self.view addSubview:name];
    [name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.girlView.mas_bottom).offset(40);
        make.left.mas_equalTo(ScaleW(30));
        make.height.mas_equalTo(ScaleW(ScaleW(22)));
        make.width.mas_equalTo(ScaleW(60));
    }];
    self.girlNameTitle = name;
    
    name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
    name.font = [UIFont boldSystemFontOfSize:FontSize(16)];
    name.text = @"";
    [self.view addSubview:name];
    [name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.girlView.mas_bottom).offset(40);
        make.left.mas_equalTo(ScaleW(160));
        make.height.mas_equalTo(ScaleW(22));
//        make.width.mas_equalTo(ScaleW(120));
    }];
    self.girlNameContent = name;
    
    UIImageView *line = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 1)];
    line.backgroundColor = rgba(232, 232, 232, 1);
    [self.view addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.self.girlNameTitle.mas_bottom).offset(10);
        make.left.mas_equalTo(ScaleW(20));
        make.height.mas_equalTo(ScaleW(1));
        make.width.mas_equalTo(Device_Width-40);
    }];
    self.line1View = line;
    //End Name
    
//    //Second Name
//   name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
//    name.text = @"外稱";
//    name.font = [UIFont systemFontOfSize:ScaleW(16)];
//    name.textColor = rgba(113,113,122,1);
//    [self.view addSubview:name];
//    [name mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.mas_equalTo(self.line1View.mas_bottom).offset(10);
//        make.left.mas_equalTo(ScaleW(30));
//        make.height.mas_equalTo(ScaleW(22));
//        make.width.mas_equalTo(ScaleW(60));
//    }];
//    self.girlSecondNameTitle = name;
    
//    name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
//    name.font = [UIFont boldSystemFontOfSize:ScaleW(16)];
//    name.text = @"最強外掛";
//    [self.view addSubview:name];
//    [name mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.mas_equalTo(self.line1View.mas_bottom).offset(10);
//        make.left.mas_equalTo(ScaleW(160));
//        make.height.mas_equalTo(ScaleW(22));
//        make.width.mas_equalTo(ScaleW(120));
//    }];
//    self.girlSecondNameContent = name;
//    
//    line = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 1)];
//    line.backgroundColor = rgba(232, 232, 232, 1);
//    [self.view addSubview:line];
//    [line mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.mas_equalTo(self.self.girlSecondNameContent.mas_bottom).offset(10);
//        make.left.mas_equalTo(ScaleW(20));
//        make.height.mas_equalTo(ScaleW(1));
//        make.width.mas_equalTo(Device_Width-40);
//    }];
//    self.line2View = line;
    //End SeceondName
    
    //birthday
   name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
    name.text = @"生日";
    name.font = [UIFont systemFontOfSize:FontSize(16)];
    name.textColor = rgba(113,113,122,1);
    [self.view addSubview:name];
    [name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.line1View.mas_bottom).offset(10);
        make.left.mas_equalTo(ScaleW(30));
        make.height.mas_equalTo(ScaleW(22));
        make.width.mas_equalTo(ScaleW(60));
    }];
    self.girlBirthdayTitle = name;
    
    name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
    name.font = [UIFont boldSystemFontOfSize:FontSize(16)];
    name.text = @"10月03日";
    [self.view addSubview:name];
    [name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.line1View.mas_bottom).offset(10);
        make.left.mas_equalTo(ScaleW(160));
        make.height.mas_equalTo(ScaleW(22));
        make.width.mas_equalTo(ScaleW(120));
    }];
    self.girlBirthdayContent = name;
    
    line = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 1)];
    line.backgroundColor = rgba(232, 232, 232, 1);
    [self.view addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.self.girlBirthdayContent.mas_bottom).offset(10);
        make.left.mas_equalTo(ScaleW(20));
        make.height.mas_equalTo(ScaleW(1));
        make.width.mas_equalTo(Device_Width-40);
    }];
    self.line3View = line;
    
    //star
    name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
     name.text = @"星座";
     name.font = [UIFont systemFontOfSize:FontSize(16)];
    name.textColor = rgba(113,113,122,1);
     [self.view addSubview:name];
     [name mas_makeConstraints:^(MASConstraintMaker *make) {
         make.top.mas_equalTo(self.line3View.mas_bottom).offset(10);
         make.left.mas_equalTo(ScaleW(30));
         make.height.mas_equalTo(ScaleW(22));
         make.width.mas_equalTo(ScaleW(60));
     }];
    self.girlStarTitle = name;
     
     name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
     name.font = [UIFont boldSystemFontOfSize:FontSize(16)];
     name.text = @"天秤座";
     [self.view addSubview:name];
     [name mas_makeConstraints:^(MASConstraintMaker *make) {
         make.top.mas_equalTo(self.line3View.mas_bottom).offset(10);
         make.left.mas_equalTo(ScaleW(160));
         make.height.mas_equalTo(ScaleW(22));
         make.width.mas_equalTo(ScaleW(120));
     }];
    self.girlStarContent = name;
     
     line = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 1)];
     line.backgroundColor = rgba(232, 232, 232, 1);
     [self.view addSubview:line];
     [line mas_makeConstraints:^(MASConstraintMaker *make) {
         make.top.mas_equalTo(self.self.girlStarContent.mas_bottom).offset(10);
         make.left.mas_equalTo(ScaleW(20));
         make.height.mas_equalTo(ScaleW(1));
         make.width.mas_equalTo(Device_Width-40);
     }];
     self.line3View = line;
    
    
    UIButton *bt = [[UIButton alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], 46, 46)];
    bt.tag = 10011;
    bt.backgroundColor = [UIColor colorWithRed:0 green:0.478 blue:0.376 alpha:1.0];
    bt.layer.cornerRadius = ScaleW(8);
    [bt setImage:[UIImage imageNamed:@"facebook"] forState:UIControlStateNormal];
    [bt addTarget:self action:@selector(buttonclick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bt];
    [bt mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.self.line3View.mas_bottom).offset(30);
        make.left.mas_equalTo(self.girlNameTitle.mas_left);
        make.height.mas_equalTo(ScaleW(46));
        make.width.mas_equalTo(ScaleW(46));
    }];
    self.facebookbt = bt;
    
    bt = [[UIButton alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], 46, 46)];
    bt.tag = 10012;
    bt.backgroundColor = [UIColor colorWithRed:0 green:0.478 blue:0.376 alpha:1.0];
    bt.layer.cornerRadius = ScaleW(8);
    [bt setImage:[UIImage imageNamed:@"instagram"] forState:UIControlStateNormal];
    [bt addTarget:self action:@selector(buttonclick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bt];
    [bt mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.self.line3View.mas_bottom).offset(30);
        make.left.mas_equalTo(self.facebookbt.mas_right).offset(30);
        make.height.mas_equalTo(ScaleW(46));
        make.width.mas_equalTo(ScaleW(46));
    }];
    self.twtiterbt = bt;
}

-(void)buttonclick:(UIButton*)bt
{
    NSString *facebookstring = [self.girlDetailinfo objectForKey:@"girlfacebookURL"];
    NSString *IGstring = [self.girlDetailinfo objectForKey:@"girligURL"];
    
    switch (bt.tag) {
        case 10011:
            [self openURL:facebookstring fallback:@"https://www.facebook.com/100083409097537"];
            break;
        case 10012:
            [self openURL:IGstring
                        fallback:@"https://www.instagram.com/tsg_hawks/"];
            break;
    }
}

- (void)openURL:(NSString *)appURL fallback:(NSString *)webURL {
    NSURL *appSchemeURL = [NSURL URLWithString:appURL];
    NSURL *webFallbackURL = [NSURL URLWithString:webURL];
    
    [[UIApplication sharedApplication] openURL:appSchemeURL
                                     options:@{}
                           completionHandler:^(BOOL success) {
        if (!success) {
            [[UIApplication sharedApplication] openURL:webFallbackURL
                                            options:@{}
                                  completionHandler:nil];
        }
    }];
}

-(void)setInfo:(NSDictionary*)girlDetailinfo
{
    [self.girlNameContent setText:[girlDetailinfo objectForKey:@"girlnickName"]];
    //[self.girlSecondNameContent setText:[girlDetailinfo objectForKey:@"girlnickName"]];
    [self.girlBirthdayContent setText:[girlDetailinfo objectForKey:@"girlbrithday"]];
    [self.girlStarContent setText:[girlDetailinfo objectForKey:@"girlstar"]];
    
    [self.Nolable_inImage setText:[girlDetailinfo objectForKey:@"girlNO"]];
    [self.Namelable_inImage setText:[girlDetailinfo objectForKey:@"girlName"]];
    [self.SecondNamelable_inImage setText:[girlDetailinfo objectForKey:@"girlsecondName"]];
    
    [self.showgirlView setImage:[UIImage imageNamed:[girlDetailinfo objectForKey:@"girImage"]]];
    
    self.facebookbt.hidden = NO;
    self.twtiterbt.hidden = NO;
    
    NSString *facebookstring = [self.girlDetailinfo objectForKey:@"girlfacebookURL"];
    NSString *IGstring = [self.girlDetailinfo objectForKey:@"girligURL"];

    if([facebookstring isEqualToString:@""])
    {
        self.facebookbt.hidden = YES;
        if([IGstring isEqualToString:@""])
        {
            self.twtiterbt.hidden = YES;
        }
        else
        {
            [self.twtiterbt mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.top.mas_equalTo(self.self.line3View.mas_bottom).offset(30);
                    make.left.mas_equalTo(self.girlNameTitle.mas_left);
                    make.height.mas_equalTo(ScaleW(46));
                    make.width.mas_equalTo(ScaleW(46));
                }];
        }
    }
    else
    {
        if([IGstring isEqualToString:@""])
        {
            self.twtiterbt.hidden = YES;
        }
        else
        {
            [self.twtiterbt mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.top.mas_equalTo(self.self.line3View.mas_bottom).offset(30);
                    make.left.mas_equalTo(self.facebookbt.mas_right).offset(30);
                    make.height.mas_equalTo(ScaleW(46));
                    make.width.mas_equalTo(ScaleW(46));
                }];
        }
        
    }
    
    
}

@end
