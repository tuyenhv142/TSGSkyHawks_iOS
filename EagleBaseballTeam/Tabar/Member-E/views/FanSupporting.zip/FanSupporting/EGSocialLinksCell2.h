//
//  EGSocialLinksCellTableViewCell.h
//  EagleBaseballTeam
//
//  Created by rick on 1/26/25.
//  Copyright © 2025 NewSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EGSocialLinksCell2 : UITableViewCell

+(instancetype)cellWithUITableView:(UITableView *)tableView;

@end

NS_ASSUME_NONNULL_END
