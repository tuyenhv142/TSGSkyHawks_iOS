//
//  ViewController.h
//  music
//
//  Created by Dragon_Zheng on 2/5/25.
//

#import <UIKit/UIKit.h>
#import "LXYHyperlinksButton.h"
@interface EGYingyuantuanDetailViewController : EGBaseViewController
{
    
    
}
@property (nonatomic,strong)NSDictionary *girlDetailinfo;

@end

