//
//  ViewController.m
//  music
//
//  Created by Dragon_Zheng on 2/5/25.
//

#import "EGFanDetailViewController.h"
#import "EGFanMemberClassInfoCell.h"
@interface EGFanDetailViewController ()<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UIImageView *girlView;
@property (nonatomic,strong)UIImageView *showgirlView;
@property (nonatomic,strong)UILabel *girlNameTitle;
@property (nonatomic,strong)UILabel *girlNameContent;
@property (nonatomic,strong)UILabel *girlSecondNameTitle;
//@property (nonatomic,strong)UILabel *girlSecondNameContent;
@property (nonatomic,strong)UILabel *girlBirthdayTitle;
@property (nonatomic,strong)UILabel *girlBirthdayContent;
@property (nonatomic,strong)UILabel *girlStarTitle;
@property (nonatomic,strong)UILabel *girlStarContent;

@property (nonatomic,strong)UIImageView *line1View;
@property (nonatomic,strong)UIImageView *line2View;
@property (nonatomic,strong)UIImageView *line3View;
@property (nonatomic,strong)UIImageView *line4View;

@property (nonatomic,strong)UIButton *facebookbt;
@property (nonatomic,strong)UIButton *twtiterbt;

@property (nonatomic,strong)UILabel *Nolable_inImage;
@property (nonatomic,strong)UILabel *Namelable_inImage;
@property (nonatomic,strong)UILabel *SecondNamelable_inImage;


@property (nonatomic, strong) UIScrollView *mainscrollView;
@property (nonatomic, assign) BOOL isUserScrolling;  // 添加标记区分用户滑动和按钮点击
@property (nonatomic, strong) UIView *bustatuslable;
@property (nonatomic, assign) NSInteger currentIndex;


@property (nonatomic, strong) UIView *girlinfo_view;//个人信息页面base view
@property (nonatomic, strong) UIView *girlclassinfo_view;//班表信息页面base view
@property (nonatomic, strong) LXYHyperlinksButton *girlinfo_bt;
@property (nonatomic, strong) LXYHyperlinksButton *girlclassinfo_bt;


@property (nonatomic, strong) UIView *girlclassinfo_Topview;
@property (nonatomic, strong) UIView *girlclassinfo_dateview;
@property (nonatomic,strong)UIButton *girlclassinfo_predate_bt;
@property (nonatomic,strong)UIButton *girlclassinfo_nextdate_bt;
@property (nonatomic,strong)UILabel *girlclassinfo_datelabel;
@property (nonatomic,strong)UITableView *girlclassinfo_tabelView;

@property (nonatomic,strong)NSArray*girlclassinfo_array;

@property (nonatomic,strong)UIImageView *helpimageView;
@property (nonatomic,strong)UILabel *helplabel;

@property (nonatomic,strong)NSDate *currentDate;
@property (nonatomic, assign) NSInteger current_year;
@property (nonatomic, assign) NSInteger current_month;
@end

@implementation EGFanDetailViewController
- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.navigationItem.title = @"鷹援資訊";
    [self setupUI];
    [self setInfo:self.girlDetailinfo];
    
    [self getclassinfo];
    
}

-(void)getclassinfo
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"girlclass" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    self.girlclassinfo_array = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingFragmentsAllowed error:nil];
    
}

-(void)setupUI
{
    UIView *bView = [[UIView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, Device_Height)];
    bView.backgroundColor = UIColor.whiteColor;
    [self.view addSubview:bView];
    
    
    UIImageView *gView = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 20)];
    
    gView.image = [UIImage imageNamed:@"Imageback"];
    [self.view addSubview:gView];
    [gView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo([UIDevice de_navigationFullHeight]);
        make.left.mas_equalTo(0);
        make.height.mas_equalTo(ScaleW(242));
        make.width.mas_equalTo(Device_Width);
    }];
    self.girlView = gView;
    
    //个人图片上面显示4个信息
    gView = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 20)];
    gView.contentMode = UIViewContentModeScaleAspectFill;
    [ self.girlView addSubview:gView];
    [gView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(0);
        make.right.mas_equalTo(ScaleW(-20));
        make.height.mas_equalTo(ScaleW(242));
        make.width.mas_equalTo(ScaleW(200));
    }];
    self.showgirlView = gView;
    
    
    UILabel *labelinimage = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], 40, 67)];
    labelinimage.textColor = UIColor.whiteColor;
    labelinimage.font = [UIFont boldSystemFontOfSize:FontSize(40)];
    [self.girlView addSubview:labelinimage];
    [labelinimage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(ScaleW(91));
        make.left.mas_equalTo(ScaleW(28));
        make.height.mas_equalTo(ScaleW(67));
        make.width.mas_equalTo(ScaleW(60));
    }];
    self.Nolable_inImage = labelinimage;
    
    
    labelinimage = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], 72, 34)];
    labelinimage.textColor = UIColor.whiteColor;
    labelinimage.font = [UIFont systemFontOfSize:FontSize(20)];
    [self.girlView addSubview:labelinimage];
    [labelinimage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(ScaleW(158));
        make.left.mas_equalTo(ScaleW(28));
        make.height.mas_equalTo(ScaleW(34));
        make.width.mas_equalTo(ScaleW(72));
    }];
    self.Namelable_inImage = labelinimage;
    
    
    labelinimage = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], 63, 22)];
    labelinimage.textColor = UIColor.whiteColor;
    labelinimage.font = [UIFont systemFontOfSize:FontSize(16)];
    [self.girlView addSubview:labelinimage];
    [labelinimage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.Namelable_inImage.mas_bottom);
        make.left.mas_equalTo(ScaleW(28));
        make.height.mas_equalTo(ScaleW(22));
//        make.width.mas_equalTo(ScaleW(63));
    }];
    self.SecondNamelable_inImage = labelinimage;
    
    NSInteger bt_width = Device_Width/2;
    LXYHyperlinksButton *bt = [[LXYHyperlinksButton alloc] initWithFrame:CGRectMake(0, 0, 100, 36)];
    bt.tag = 50000;
    [bt setTitle:@"基本資料" forState:UIControlStateNormal];
    [bt setTitleColor:rgba(212, 212, 212, 1) forState:UIControlStateSelected];
    [bt setTitleColor:rgba(23, 23, 23, 1) forState:UIControlStateNormal];
    bt.titleLabel.font = [UIFont systemFontOfSize:FontSize(14) weight:UIFontWeightSemibold];
    [bt addTarget:self action:@selector(buttonclick1:) forControlEvents:(UIControlEventTouchUpInside)];

    [self.view addSubview:bt];
    [bt setColor:/*rgba(0, 122, 96, 1)*/[UIColor clearColor]];
    self.girlinfo_bt = bt;
    [self.girlinfo_bt setSelected:YES];
    [bt mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(ScaleW(0));
        make.top.mas_equalTo(self.girlView.mas_bottom);
            make.width.mas_equalTo(bt_width);
            make.height.mas_equalTo(ScaleW(50));
        }];
    [self.girlinfo_bt setTitleColor:rgba(23, 23, 23, 1) forState:UIControlStateSelected];
    [self.girlinfo_bt setTitleColor:rgba(115, 115, 115, 1) forState:UIControlStateNormal];
    [self.girlinfo_bt setColor:[UIColor clearColor]];
    
    
    bt = [[LXYHyperlinksButton alloc] initWithFrame:CGRectMake(0, 0, 100, 36)];
    bt.tag = 50001;
    [bt setTitle:@"個人班表" forState:UIControlStateNormal];
    [bt setTitleColor:rgba(212, 212, 212, 1) forState:UIControlStateSelected];
    [bt setTitleColor:rgba(23, 23, 23, 1) forState:UIControlStateNormal];
    bt.titleLabel.font = [UIFont systemFontOfSize:FontSize(14) weight:UIFontWeightSemibold];
    [bt addTarget:self action:@selector(buttonclick1:) forControlEvents:(UIControlEventTouchUpInside)];

    [self.view addSubview:bt];
    [bt setColor:/*rgba(0, 122, 96, 1)*/[UIColor clearColor]];
    self.girlclassinfo_bt = bt;
    [self.girlclassinfo_bt setSelected:NO];
    [bt mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.girlinfo_bt.mas_right).offset(0);
        make.top.mas_equalTo(self.girlView.mas_bottom);
            make.width.mas_equalTo(bt_width);
            make.height.mas_equalTo(ScaleW(50));
        }];
    
    [self.girlclassinfo_bt setTitleColor:rgba(23, 23, 23, 1) forState:UIControlStateSelected];
    [self.girlclassinfo_bt setTitleColor:rgba(115, 115, 115, 1) forState:UIControlStateNormal];
    [self.girlclassinfo_bt setColor:[UIColor clearColor]];
    
    
    // 滑块指示器
    
    
    self.bustatuslable = [[UIView alloc] init];
    self.bustatuslable.backgroundColor = rgba(0, 122, 96, 1); //rgba(0, 122, 96, 1)
    [self.view addSubview:self.bustatuslable];
        
    [self.bustatuslable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.girlclassinfo_bt.mas_bottom);
        //make.bottom.equalTo(self.girlView.frame.size.height + );
        make.width.mas_equalTo(bt_width);
        make.height.mas_equalTo(ScaleW(4));
        make.left.mas_equalTo(self.view.mas_left).offset(ScaleW(0));
    }];
    [self updateSelectedButton:0];
    
    
    //add scroller
    // 滚动视图
    self.mainscrollView = [[UIScrollView alloc] init];
    self.mainscrollView.backgroundColor = [UIColor colorWithRed:0.962 green:0.962 blue:0.962 alpha:1.0];
    self.mainscrollView.delegate = self;
    self.mainscrollView.pagingEnabled = YES;
      
    self.mainscrollView.scrollEnabled = YES;
    self.mainscrollView.showsHorizontalScrollIndicator = YES;
    [self.view addSubview:self.mainscrollView];
        [self.mainscrollView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(self.topView.mas_bottom);
            make.top.equalTo(self.girlclassinfo_bt.mas_bottom).offset(ScaleW(4));
            
            make.left.right.bottom.equalTo(self.view);
        }];
    self.mainscrollView.contentSize = CGSizeMake(UIScreen.mainScreen.bounds.size.width * 2, 0);
    self.mainscrollView.bounces = YES;
    
    //add 球员详细界面
    self.girlinfo_view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, Device_Width, Device_Height-[UIDevice de_navigationFullHeight]-self.girlView.frame.size.height-self.girlclassinfo_bt.frame.size.height)];
    [self.mainscrollView addSubview:self.girlinfo_view];

    [self setgirlInfoUI];/*设置个人信息页面*/
    
    
    //add 班表详细信息页面
    self.girlclassinfo_view = [[UIView alloc] initWithFrame:CGRectMake(Device_Width, 0, Device_Width, Device_Height-[UIDevice de_navigationFullHeight]-self.girlView.frame.size.height-self.girlclassinfo_bt.frame.size.height)];
    [self.mainscrollView addSubview:self.girlclassinfo_view];
    
    [self setgirlclassUI];///*设置个人班表页面*/
    
}

-(void)buttonclick:(UIButton*)bt
{
    NSString *facebookstring = [self.girlDetailinfo objectForKey:@"girlfacebookURL"];
    NSString *IGstring = [self.girlDetailinfo objectForKey:@"girligURL"];
    
    switch (bt.tag) {
        case 10011:
            [self openURL:facebookstring fallback:@"https://www.facebook.com/100083409097537"];
            break;
        case 10012:
            [self openURL:IGstring
                        fallback:@"https://www.instagram.com/tsg_hawks/"];
            break;
    }
}

- (void)openURL:(NSString *)appURL fallback:(NSString *)webURL {
    NSURL *appSchemeURL = [NSURL URLWithString:appURL];
    NSURL *webFallbackURL = [NSURL URLWithString:webURL];
    
    [[UIApplication sharedApplication] openURL:appSchemeURL
                                     options:@{}
                           completionHandler:^(BOOL success) {
        if (!success) {
            [[UIApplication sharedApplication] openURL:webFallbackURL
                                            options:@{}
                                  completionHandler:nil];
        }
    }];
}

-(void)setInfo:(NSDictionary*)girlDetailinfo
{
    [self.girlNameContent setText:[girlDetailinfo objectForKey:@"girlnickName"]];
    //[self.girlSecondNameContent setText:[girlDetailinfo objectForKey:@"girlnickName"]];
    [self.girlBirthdayContent setText:[girlDetailinfo objectForKey:@"girlbrithday"]];
    [self.girlStarContent setText:[girlDetailinfo objectForKey:@"girlstar"]];
    
    [self.Nolable_inImage setText:[girlDetailinfo objectForKey:@"girlNO"]];
    [self.Namelable_inImage setText:[girlDetailinfo objectForKey:@"girlName"]];
    [self.SecondNamelable_inImage setText:[girlDetailinfo objectForKey:@"girlsecondName"]];
    
    [self.showgirlView setImage:[UIImage imageNamed:[girlDetailinfo objectForKey:@"girImage"]]];
    
    self.facebookbt.hidden = NO;
    self.twtiterbt.hidden = NO;
    
    NSString *facebookstring = [self.girlDetailinfo objectForKey:@"girlfacebookURL"];
    NSString *IGstring = [self.girlDetailinfo objectForKey:@"girligURL"];

    if([facebookstring isEqualToString:@""])
    {
        self.facebookbt.hidden = YES;
        if([IGstring isEqualToString:@""])
        {
            self.twtiterbt.hidden = YES;
        }
        else
        {
            [self.twtiterbt mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.top.mas_equalTo(self.self.line3View.mas_bottom).offset(30);
                    make.left.mas_equalTo(self.girlNameTitle.mas_left);
                    make.height.mas_equalTo(ScaleW(46));
                    make.width.mas_equalTo(ScaleW(46));
                }];
        }
    }
    else
    {
        if([IGstring isEqualToString:@""])
        {
            self.twtiterbt.hidden = YES;
        }
        else
        {
            [self.twtiterbt mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.top.mas_equalTo(self.self.line3View.mas_bottom).offset(30);
                    make.left.mas_equalTo(self.facebookbt.mas_right).offset(30);
                    make.height.mas_equalTo(ScaleW(46));
                    make.width.mas_equalTo(ScaleW(46));
                }];
        }
        
    }
    
    
}

- (void)updateSelectedButton:(NSInteger)index {
    self.currentIndex = index;
   
    NSInteger bt_w = Device_Width/2;
    [UIView animateWithDuration:0.3 animations:^{
        self.bustatuslable.transform = CGAffineTransformMakeTranslation(index * bt_w, 0);
    }];
    
   
}


-(void)setgirlclassUI
{
    UIView *bView = [[UIView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, Device_Height)];
    bView.layer.cornerRadius = ScaleW(10);
    bView.backgroundColor = UIColor.whiteColor;
    [self.girlclassinfo_view addSubview:bView];
    [bView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(ScaleW(10));
        make.centerX.mas_equalTo(self.girlclassinfo_view.mas_centerX);
        make.height.mas_equalTo(ScaleW(65));
        make.width.mas_equalTo(ScaleW(335));
    }];
    self.girlclassinfo_Topview = bView;
    
    bView = [[UIView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, Device_Height)];
    bView.layer.cornerRadius = ScaleW(15);
    bView.backgroundColor = ColorRGB(0xF3F4F6);
    [self.girlclassinfo_Topview addSubview:bView];
    [bView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.girlclassinfo_Topview.mas_centerY);
        make.centerX.mas_equalTo(self.girlclassinfo_Topview.mas_centerX);
        make.height.mas_equalTo(ScaleW(30));
        make.width.mas_equalTo(ScaleW(300));
    }];
    self.girlclassinfo_dateview = bView;
    
    
    UIButton *rememberBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rememberBtn.tag = 101;
    rememberBtn.hitTestEdgeInsets = UIEdgeInsetsMake(-5, -5, -5, -50);
    [rememberBtn setImage:[UIImage imageNamed:@"check-square-no"] forState:UIControlStateNormal];
    [rememberBtn setImage:[UIImage imageNamed:@"Checkboxes"] forState:UIControlStateSelected];//gouXuanC
    [rememberBtn addTarget:self action:@selector(changeDate:) forControlEvents:UIControlEventTouchUpInside];
    [self.girlclassinfo_dateview addSubview:rememberBtn];
    [rememberBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.girlclassinfo_dateview.mas_centerY);
        make.left.mas_equalTo(ScaleW(5));
        make.height.width.mas_equalTo(ScaleW(25));
    }];
    
    
    rememberBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rememberBtn.tag = 102;
    rememberBtn.hitTestEdgeInsets = UIEdgeInsetsMake(-5, -5, -5, -50);
    [rememberBtn setImage:[UIImage imageNamed:@"check-square-no"] forState:UIControlStateNormal];
    [rememberBtn setImage:[UIImage imageNamed:@"Checkboxes"] forState:UIControlStateSelected];//gouXuanC
    [rememberBtn addTarget:self action:@selector(changeDate:) forControlEvents:UIControlEventTouchUpInside];
    [self.girlclassinfo_dateview addSubview:rememberBtn];
    [rememberBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.girlclassinfo_dateview.mas_centerY);
        make.right.mas_equalTo(-ScaleW(5));
        make.height.width.mas_equalTo(ScaleW(25));
    }];
    
    
    UILabel *labelinimage = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], 40, 67)];
    labelinimage.text = @"2025/04";
    labelinimage.textColor = UIColor.blackColor;
    labelinimage.font = [UIFont boldSystemFontOfSize:FontSize(18)];
    [self.girlclassinfo_dateview addSubview:labelinimage];
    [labelinimage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.girlclassinfo_dateview.mas_centerY);
        make.centerX.mas_equalTo(self.girlclassinfo_dateview.mas_centerX);
        make.height.mas_equalTo(ScaleW(24));
        make.width.mas_equalTo(ScaleW(80));
    }];
    self.girlclassinfo_datelabel = labelinimage;
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    self.currentDate = [NSDate date];
    self.current_year = [calendar component:NSCalendarUnitYear fromDate:self.currentDate];
    self.current_month = [calendar component:NSCalendarUnitMonth fromDate:self.currentDate];
    NSLog(@"year = %ld, month = %ld",self.current_year,self.current_month);
    [self.girlclassinfo_datelabel setText:[self dateFromYEARandMonth:self.current_year M:self.current_month]];
    
    
    
    NSInteger table_height = ScaleW(300);//Device_Height-[UIDevice de_navigationFullHeight]-self.girlView.frame.size.height-self.girlclassinfo_bt.frame.size.height - ScaleW(65);
    UITableView *tableView2 = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped];
    tableView2.delegate = self;
    tableView2.dataSource = self;
    tableView2.backgroundColor = rgba(245, 245, 245, 1);
    
    tableView2.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView2.showsVerticalScrollIndicator = NO;
    tableView2.estimatedRowHeight = 100;
    self.girlclassinfo_tabelView = tableView2;
    [self.girlclassinfo_view addSubview:self.girlclassinfo_tabelView];
    [self.girlclassinfo_tabelView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(ScaleW(0));
        make.centerX.mas_equalTo(self.girlclassinfo_view.mas_centerX);
        //make.bottom.mas_equalTo(-ScaleW(20));
        make.height.mas_equalTo(table_height);
        make.top.mas_equalTo(self.girlclassinfo_Topview.mas_bottom).offset(ScaleW(5));
    }];
    
    UIImageView *line = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 1)];
    line.image = [UIImage imageNamed:@"Ellipse"];
    [self.girlclassinfo_view addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.girlclassinfo_tabelView.mas_bottom).offset(ScaleW(15));
        make.left.mas_equalTo(ScaleW(40));
        make.height.mas_equalTo(ScaleW(10));
        make.width.mas_equalTo(ScaleW(10));
    }];
    self.helpimageView = line;
    
    
    UILabel *labelini = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], 40, 67)];
    labelini.textColor = ColorRGB(0x6B7280);
    labelini.text = @"排班日               以上為澄清湖棒球場 Wing Stars 班表";
    labelini.textColor = UIColor.blackColor;
    labelini.font = [UIFont systemFontOfSize:FontSize(12)];
    [self.girlclassinfo_view addSubview:labelini];
    [labelini mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.helpimageView.mas_right).offset(ScaleW(5));
        make.centerY.mas_equalTo(self.helpimageView.mas_centerY);
        make.height.mas_equalTo(ScaleW(20));
        make.width.mas_equalTo(ScaleW(300));
    }];
    self.helplabel = labelini;
    
}
#pragma mark ------------改变日期功能
-(void)changeDate:(UIButton*)bt
{
    switch (bt.tag) {
        case 101://前一个月
            [self beforeDate];
            break;
            
            
        case 102://后一个月
            [self nextDate];
            break;
        
    }
    
}

-(void)beforeDate
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth /*| NSCalendarUnitDay*/ fromDate:self.currentDate];
    
    //NSDate *end_date = self.currentDate;//往前一个月，先记录的时间是end date
    // 获取当前月份
    NSInteger currentMonth = [components month];
    // 减去一个月
    components.month = currentMonth - 1;
    self.currentDate = [calendar dateFromComponents:components];
    
    self.current_year = [calendar component:NSCalendarUnitYear fromDate:self.currentDate];
    self.current_month = [calendar component:NSCalendarUnitMonth fromDate:self.currentDate];
    NSLog(@"year = %ld, month = %ld",self.current_year,self.current_month);
    
    [self.girlclassinfo_datelabel setText:[self dateFromYEARandMonth:self.current_year M:self.current_month]];
    
    NSDate *end_date = [self getlastday:self.current_year M:self.current_month];
    NSDate *startDate = [self getfirstday:self.current_year M:self.current_month];
    
    //从Array中按照年月过滤数据，如果你想要基于日期的某些特定部分（例如只比较年份和月份），你可以使用NSDateComponents来创建一个比较器：
    NSPredicate *predicate1 = [NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        NSString *dateV = (NSString *)evaluatedObject[@"ChgDate"];
        NSDateFormatter *inputFormatter = [[NSDateFormatter alloc] init];
        [inputFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss'Z'"];
        [inputFormatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
        NSDate *date = [inputFormatter dateFromString:dateV];
        
        return ([date compare:startDate] != NSOrderedAscending) && ([date compare:end_date] != NSOrderedDescending);
    }];
    
    //self.teamProformentsArray = [self.teamProformentsMainArray filteredArrayUsingPredicate:predicate1];
    
}



-(void)nextDate
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:self.currentDate];
     
    //NSDate *start_date = self.currentDate;
    
    // 获取当前月份
    NSInteger currentMonth = [components month];
     
    // 加上一个月
    components.month = currentMonth + 1;
    self.currentDate = [calendar dateFromComponents:components];
    self.current_year = [calendar component:NSCalendarUnitYear fromDate:self.currentDate];
    self.current_month = [calendar component:NSCalendarUnitMonth fromDate:self.currentDate];
    NSLog(@"year = %ld, month = %ld",self.current_year,self.current_month);
    [self.girlclassinfo_datelabel setText:[self dateFromYEARandMonth:self.current_year M:self.current_month]];
    
    NSDate *end_date = [self getlastday:self.current_year M:self.current_month];
    NSDate *startDate = [self getfirstday:self.current_year M:self.current_month];
    
    
    
    NSPredicate *predicate1 = [NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        NSString *dateV = (NSString *)evaluatedObject[@"ChgDate"];
        NSDateFormatter *inputFormatter = [[NSDateFormatter alloc] init];
        [inputFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss'Z'"];
        [inputFormatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
        NSDate *date = [inputFormatter dateFromString:dateV];
        
        return ([date compare:startDate] != NSOrderedAscending) && ([date compare:end_date] != NSOrderedDescending);
    }];
    
    //self.teamProformentsArray = [self.teamProformentsMainArray filteredArrayUsingPredicate:predicate1];
    
     
}

-(NSString*)dateFromYEARandMonth:(NSInteger)year M:(NSInteger)month
{
    NSString *string = [NSString new];
    if(month<10)
      string = [string stringByAppendingFormat:@"%ld/0%ld",year,month];
    else
        string = [string stringByAppendingFormat:@"%ld/%ld",year,month];
    return string;
}

-(NSDate*)getfirstday:(NSInteger)year M:(NSInteger)month
{
    NSCalendar *calendar = [NSCalendar currentCalendar];

    // 获取该月的第一天
    NSDate *firstDayOfMonth = nil;
    NSDateComponents *components = [[NSDateComponents alloc] init];
    [components setYear:year];
    [components setMonth:month];
    [components setDay:1]; // 设置第一天为该月的第一天
    firstDayOfMonth = [calendar dateFromComponents:components]; // 使用这个日期对象来获取这个月的信息
    return firstDayOfMonth;
}

-(NSDate*)getlastday:(NSInteger)year M:(NSInteger)month
{
    NSCalendar *calendar = [NSCalendar currentCalendar];

    // 获取该月的第一天
    NSDate *firstDayOfMonth = nil;
    NSDateComponents *components = [[NSDateComponents alloc] init];
    [components setYear:year];
    [components setMonth:month];
    [components setDay:1]; // 设置第一天为该月的第一天
    firstDayOfMonth = [calendar dateFromComponents:components]; // 使用这个日期对象来获取这个月的信息
    
    
    
    components.month += 1;
    components.day = 1;
    NSDate *nextMonthFirstDay = [calendar dateFromComponents:components];
     
    // 减去一天得到当前月份的最后一天
    NSDate *lastDayOfMonth = [calendar dateByAddingUnit:NSCalendarUnitDay value:-1 toDate:nextMonthFirstDay options:0];

    return lastDayOfMonth;
}


-(void)setgirlInfoUI
{
        //Name
        UILabel *name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
        name.text = @"姓名";
        name.font = [UIFont systemFontOfSize:FontSize(16)];
        name.textColor = rgba(113,113,122,1);
        [self.girlinfo_view addSubview:name];
        [name mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.girlinfo_bt.mas_bottom).offset(40);
            make.left.mas_equalTo(ScaleW(30));
            make.height.mas_equalTo(ScaleW(ScaleW(22)));
            make.width.mas_equalTo(ScaleW(60));
        }];
        self.girlNameTitle = name;
        
        name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
        name.font = [UIFont boldSystemFontOfSize:FontSize(16)];
        name.text = @"";
        [self.girlinfo_view addSubview:name];
        [name mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.girlinfo_bt.mas_bottom).offset(40);
            make.left.mas_equalTo(ScaleW(160));
            make.height.mas_equalTo(ScaleW(22));
    //        make.width.mas_equalTo(ScaleW(120));
        }];
        self.girlNameContent = name;
        
        UIImageView *line = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 1)];
        line.backgroundColor = rgba(232, 232, 232, 1);
        [self.girlinfo_view addSubview:line];
        [line mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.self.girlNameTitle.mas_bottom).offset(10);
            make.left.mas_equalTo(ScaleW(20));
            make.height.mas_equalTo(ScaleW(1));
            make.width.mas_equalTo(Device_Width-40);
        }];
        self.line1View = line;
        //End Name
        
    //    //Second Name
    //   name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
    //    name.text = @"外稱";
    //    name.font = [UIFont systemFontOfSize:ScaleW(16)];
    //    name.textColor = rgba(113,113,122,1);
    //    [self.view addSubview:name];
    //    [name mas_makeConstraints:^(MASConstraintMaker *make) {
    //        make.top.mas_equalTo(self.line1View.mas_bottom).offset(10);
    //        make.left.mas_equalTo(ScaleW(30));
    //        make.height.mas_equalTo(ScaleW(22));
    //        make.width.mas_equalTo(ScaleW(60));
    //    }];
    //    self.girlSecondNameTitle = name;
        
    //    name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
    //    name.font = [UIFont boldSystemFontOfSize:ScaleW(16)];
    //    name.text = @"最強外掛";
    //    [self.view addSubview:name];
    //    [name mas_makeConstraints:^(MASConstraintMaker *make) {
    //        make.top.mas_equalTo(self.line1View.mas_bottom).offset(10);
    //        make.left.mas_equalTo(ScaleW(160));
    //        make.height.mas_equalTo(ScaleW(22));
    //        make.width.mas_equalTo(ScaleW(120));
    //    }];
    //    self.girlSecondNameContent = name;
    //
    //    line = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 1)];
    //    line.backgroundColor = rgba(232, 232, 232, 1);
    //    [self.view addSubview:line];
    //    [line mas_makeConstraints:^(MASConstraintMaker *make) {
    //        make.top.mas_equalTo(self.self.girlSecondNameContent.mas_bottom).offset(10);
    //        make.left.mas_equalTo(ScaleW(20));
    //        make.height.mas_equalTo(ScaleW(1));
    //        make.width.mas_equalTo(Device_Width-40);
    //    }];
    //    self.line2View = line;
        //End SeceondName
        
        //birthday
       name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
        name.text = @"生日";
        name.font = [UIFont systemFontOfSize:FontSize(16)];
        name.textColor = rgba(113,113,122,1);
        [self.girlinfo_view addSubview:name];
        [name mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.line1View.mas_bottom).offset(10);
            make.left.mas_equalTo(ScaleW(30));
            make.height.mas_equalTo(ScaleW(22));
            make.width.mas_equalTo(ScaleW(60));
        }];
        self.girlBirthdayTitle = name;
        
        name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
        name.font = [UIFont boldSystemFontOfSize:FontSize(16)];
        name.text = @"10月03日";
        [self.girlinfo_view addSubview:name];
        [name mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.line1View.mas_bottom).offset(10);
            make.left.mas_equalTo(ScaleW(160));
            make.height.mas_equalTo(ScaleW(22));
            make.width.mas_equalTo(ScaleW(120));
        }];
        self.girlBirthdayContent = name;
        
        line = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 1)];
        line.backgroundColor = rgba(232, 232, 232, 1);
        [self.girlinfo_view addSubview:line];
        [line mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.self.girlBirthdayContent.mas_bottom).offset(10);
            make.left.mas_equalTo(ScaleW(20));
            make.height.mas_equalTo(ScaleW(1));
            make.width.mas_equalTo(Device_Width-40);
        }];
        self.line3View = line;
        
        //star
        name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
         name.text = @"星座";
         name.font = [UIFont systemFontOfSize:FontSize(16)];
        name.textColor = rgba(113,113,122,1);
         [self.girlinfo_view addSubview:name];
         [name mas_makeConstraints:^(MASConstraintMaker *make) {
             make.top.mas_equalTo(self.line3View.mas_bottom).offset(10);
             make.left.mas_equalTo(ScaleW(30));
             make.height.mas_equalTo(ScaleW(22));
             make.width.mas_equalTo(ScaleW(60));
         }];
        self.girlStarTitle = name;
         
         name = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 22)];
         name.font = [UIFont boldSystemFontOfSize:FontSize(16)];
         name.text = @"天秤座";
         [self.girlinfo_view addSubview:name];
         [name mas_makeConstraints:^(MASConstraintMaker *make) {
             make.top.mas_equalTo(self.line3View.mas_bottom).offset(10);
             make.left.mas_equalTo(ScaleW(160));
             make.height.mas_equalTo(ScaleW(22));
             make.width.mas_equalTo(ScaleW(120));
         }];
        self.girlStarContent = name;
         
         line = [[UIImageView alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], Device_Width, 1)];
         line.backgroundColor = rgba(232, 232, 232, 1);
         [self.girlinfo_view addSubview:line];
         [line mas_makeConstraints:^(MASConstraintMaker *make) {
             make.top.mas_equalTo(self.self.girlStarContent.mas_bottom).offset(10);
             make.left.mas_equalTo(ScaleW(20));
             make.height.mas_equalTo(ScaleW(1));
             make.width.mas_equalTo(Device_Width-40);
         }];
         self.line3View = line;
        
        
        UIButton *bt = [[UIButton alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], 46, 46)];
        bt.tag = 10011;
        bt.backgroundColor = [UIColor colorWithRed:0 green:0.478 blue:0.376 alpha:1.0];
        bt.layer.cornerRadius = ScaleW(8);
        [bt setImage:[UIImage imageNamed:@"facebook"] forState:UIControlStateNormal];
        [bt addTarget:self action:@selector(buttonclick:) forControlEvents:UIControlEventTouchUpInside];
        [self.girlinfo_view addSubview:bt];
        [bt mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.self.line3View.mas_bottom).offset(30);
            make.left.mas_equalTo(self.girlNameTitle.mas_left);
            make.height.mas_equalTo(ScaleW(46));
            make.width.mas_equalTo(ScaleW(46));
        }];
        self.facebookbt = bt;
        
        bt = [[UIButton alloc] initWithFrame:CGRectMake(0, [UIDevice de_navigationFullHeight], 46, 46)];
        bt.tag = 10012;
        bt.backgroundColor = [UIColor colorWithRed:0 green:0.478 blue:0.376 alpha:1.0];
        bt.layer.cornerRadius = ScaleW(8);
        [bt setImage:[UIImage imageNamed:@"instagram"] forState:UIControlStateNormal];
        [bt addTarget:self action:@selector(buttonclick:) forControlEvents:UIControlEventTouchUpInside];
        [self.girlinfo_view addSubview:bt];
        [bt mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.self.line3View.mas_bottom).offset(30);
            make.left.mas_equalTo(self.facebookbt.mas_right).offset(30);
            make.height.mas_equalTo(ScaleW(46));
            make.width.mas_equalTo(ScaleW(46));
        }];
        self.twtiterbt = bt;
    
    
}

-(void)setscrollerView:(NSInteger)bt_index
{
    self.isUserScrolling = NO;  // 标记为按钮点击
    [self.girlinfo_bt setColor:[UIColor clearColor]];
    [self.girlclassinfo_bt setColor:[UIColor clearColor]];
    
    // 重置所有按钮状态
    [self.girlinfo_bt setSelected:NO];
    [self.girlclassinfo_bt setSelected:NO];
    
    self.girlinfo_view.hidden = NO;
    self.girlclassinfo_view.hidden = NO;
    
    
    switch (bt_index) {
        case 50000:
        {
            [self.girlinfo_bt setSelected:YES];
            [self.girlinfo_bt setColor:/*rgba(0, 122, 96, 1)*/[UIColor clearColor]];
            self.girlinfo_view.hidden = NO;
        }
            break;
        case 50001:
        {
            [self.girlclassinfo_bt setSelected:YES];
            [self.girlclassinfo_bt setColor:/*rgba(0, 122, 96, 1)*/[UIColor clearColor]];
            self.girlclassinfo_view.hidden = NO;
        }
            break;
     
    }
    
//        [self updateSelectedButton:bt.tag-50000];
//        [self.mainscrollView setContentOffset:CGPointMake((bt.tag-50000) * UIScreen.mainScreen.bounds.size.width, 0) animated:YES];

}

-(void)buttonclick1:(UIButton*)bt
{
    self.isUserScrolling = NO;  // 标记为按钮点击
    [self.girlinfo_bt setColor:[UIColor clearColor]];
    [self.girlclassinfo_bt setColor:[UIColor clearColor]];
    
    // 重置所有按钮状态
    [self.girlinfo_bt setSelected:NO];
    [self.girlclassinfo_bt setSelected:NO];
    
    self.girlinfo_view.hidden = NO;
    self.girlclassinfo_view.hidden = NO;
    
    
    switch (bt.tag) {
        case 50000:
        {
            [self.girlinfo_bt setSelected:YES];
            [self.girlinfo_bt setColor:/*rgba(0, 122, 96, 1)*/[UIColor clearColor]];
            self.girlinfo_view.hidden = NO;
        }
            break;
        case 50001:
        {
            [self.girlclassinfo_bt setSelected:YES];
            [self.girlclassinfo_bt setColor:/*rgba(0, 122, 96, 1)*/[UIColor clearColor]];
            self.girlclassinfo_view.hidden = NO;
        }
            break;
     
    }
    
        [self updateSelectedButton:bt.tag-50000];
        [self.mainscrollView setContentOffset:CGPointMake((bt.tag-50000) * UIScreen.mainScreen.bounds.size.width, 0) animated:YES];

}
#pragma mark  Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.girlclassinfo_array.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
//    return ScaleW(55);;
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

        NSDictionary *section = self.girlclassinfo_array[indexPath.row];
        EGFanMemberClassInfoCell *cell= [EGFanMemberClassInfoCell cellWithUITableView:tableView];
        
    if (indexPath.row % 2 == 0)
        cell.backgroundColor = ColorRGB(0xF9FAFB);
    else
        cell.backgroundColor = UIColor.whiteColor;
        [cell setupWithInfo:section];
       
        return cell;
    
}


#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if ([scrollView isKindOfClass:[UICollectionView class]])
    {
        return;
    }

    if ([scrollView isKindOfClass:[UITableView class]])
    {
        return;
    }
    
    NSInteger index = scrollView.contentOffset.x / UIScreen.mainScreen.bounds.size.width;
    
    [self setscrollerView:index + 50000];
    [self updateSelectedButton:index];

}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    self.isUserScrolling = YES;  // 标记为用户滑动
    
}

- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset{
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (!self.isUserScrolling) return;  // 非用户滑动时不更新滑块位置
    
    if ([scrollView isKindOfClass:[UICollectionView class]])
    {
        return;
    }
    
    if ([scrollView isKindOfClass:[UITableView class]])
    {
        return;
    }
    
    CGFloat pageWidth = scrollView.frame.size.width;
    CGFloat offsetX = scrollView.contentOffset.x;
    CGFloat progress = offsetX / pageWidth;
    // 更新滑块位置
    CGFloat buttonWidth = Device_Width/2;
    self.bustatuslable.transform = CGAffineTransformMakeTranslation(progress * buttonWidth, 0);
}
@end
